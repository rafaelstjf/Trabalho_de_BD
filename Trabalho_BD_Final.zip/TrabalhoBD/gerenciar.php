<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Trabalho de Banco de Dados</title>

<script type="text/javascript" src="JS/script.js"></script>

</head>
<body> 


	<table border='1' align='center'>
			<tr align='center'>	
				<td><a href="cadastro_pjuridica.php">Cadastrar Fornecedor</a></td>
				<td><a href="cadastro_produto_item.php">Cadastrar Produtos</a></td>
				<td><a href="cadastro_deposito.php">Cadastrar Depósito</a></td>

				<td><a href="listar_cliente.php">Listar Clientes</a></td>
				<td><a href="listar_fornecedores.php">Listar Fornecedores</a></td>
				<td><a href="listar_regiao_deposito.php">Listar Regiões/Depósito</a></td>
				<td><a href="lista_produtos2.php">Listar Produtos</a></td>
				<td><a href="estoquebaixo.php">Ver produtos em baixa nos estoques</a></td>
			</tr>			

	</table>

</body>
</html>











